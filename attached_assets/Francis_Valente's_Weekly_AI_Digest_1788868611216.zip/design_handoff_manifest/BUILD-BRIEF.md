# Replit Agent Build Brief: Manifest (francisvalente.com)

## Project

Replace the tabbed index on francisvalente.com with a single flat manifest. Everything the site holds (prompts, packs, notes, digest issues) lists on one page as rows in one ledger. The job is unchanged: find a thing, copy it, leave. This brief is the spec. Where it conflicts with the earlier Prompt Index brief, this brief wins. Where it is silent, the earlier brief and replit.md still apply (dependency budget, mobile rules, noindex, byte-exact COPY, /pay untouched).

A working HTML reference of the finished design ships alongside this brief as `Index Alt - Manifest.dc.html` with `content.js`. It is a design reference, not code to copy. Match it visually and behaviourally in the existing Vite + React + Tailwind app.

## Stack

Unchanged. Vite + React, wouter, marked, JetBrains Mono via @fontsource, Gladiator self-hosted at `src/assets/fonts/Gladiator-normal.ttf`. No new dependencies.

## Content model

Four kinds of item render in one manifest. Every item has: ref, kind, title, tags, updated, and exactly one action.

- Prompts: existing `content/prompts/*.md`. ref = frontmatter id (001). kind = frontmatter type (Protocol, Prompt, Snippet). tags = platforms. action = COPY (raw body, frontmatter excluded, byte exact).
- Packs: existing `content/launch-ready/*.md` and `content/connect/*.md`. ref = `LR` + order for Launch ready, `CN` + order for Connect. kind = Launch ready or Connect. tags = the frontmatter `file` name. action = COPY. Connect items additionally show DOWNLOAD inside the expanded body, saving the body under the frontmatter file name.
- Notes: `content/explainers/*.md` (skills.md today) and the brand skill. ref = `N` + two digit order (N01, N02). kind = frontmatter kind, default Explainer; the brand skill is kind Skill with title "Make a brand skill" and body = the six numbered steps followed by a blank line and the example skill file. tags = file name or skill name. action = COPY.
- Digest: a new `content/digest/*.md`, one file per issue, frontmatter `issue: "001"`, `title`, `updated`, `url`. ref = issue. kind = Issue. tags = [Email]. action = OPEN, a real anchor to `url`, same tab. No expand.

Frontmatter `updated` is now displayed (see Row). Section order is fixed: Prompts, Packs, Notes, Digest. Within a section, rows sort by ref ascending. A section with no rows, or with all rows filtered out, does not render at all, header included.

## Page

One page at `/`. Remove the tab nav and the `/brand`, `/launch`, `/connect` routes; redirect them to `/`. Keep the unknown-path redirect and its one-time notice.

### Status line

Sticky at the top, background #0a0a0a, hairline #1f1f1f below, padding 16px vertical and clamp(16px, 4vw, 40px) horizontal. CSS grid with three columns: auto, minmax(0, 1fr), auto, aligned on the baseline, 24px gap.

1. Left: the current Melbourne time, HH:MM, 24 hour, updating every second, in Gladiator at 36px, font-weight normal, line-height 1, letter-spacing 0.04em, colour #e6e6e6. Beside it on the same baseline: the date as `Mon 8 Sep 2026 · Melbourne` in 11px uppercase, letter-spacing 0.1em, #8a8a8a. Timezone is always Australia/Melbourne regardless of the visitor.
2. Middle: a `/` glyph in #8a8a8a 13px, then the filter input. Transparent background, no border except a 1px bottom border #1f1f1f that turns #ff5c00 on focus, no outline, padding 4px 0, JetBrains Mono 14px #e6e6e6, placeholder "filter" in #8a8a8a, max-width 420px. Case-insensitive substring match across ref, kind, title, section and tags. `/` focuses it, Esc clears it and blurs, Enter blurs. When nothing matches, the manifest shows a single grey line: 0 results.
3. Right: `12 of 12 items` in 11px uppercase, letter-spacing 0.1em, #8a8a8a. First number is the filtered count. Hidden below 760px.

There is no masthead, no name, no tagline, no logo, no nav.

### Manifest

Main column: padding 8px top, clamp(16px, 4vw, 40px) sides, 120px bottom, max-width 1180px, sections stacked with 36px gap.

Section header: two column grid (label left, count right) on the baseline, padding 28px 0 8px, hairline #1f1f1f below. Label is 11px, weight 500, letter-spacing 0.14em, uppercase, #8a8a8a. Count is the row count zero padded to two digits, 11px, letter-spacing 0.1em, #8a8a8a.

Row: a wrapper with hairline #1f1f1f below and a 2px left border (transparent, or #ff5c00 when the row holds the cursor), pulled 2px left so text still aligns with the section header. Inside, a grid with 16px gaps and padding 11px 0 11px 14px:

`52px 84px minmax(0, 2fr) minmax(0, 1fr) 84px 64px`

Columns in order:
- ref: 12px #8a8a8a
- kind: 11px uppercase, letter-spacing 0.1em, #8a8a8a
- title: 14px weight 500 #e6e6e6, wraps, overflow-wrap anywhere
- tags: 12px #8a8a8a, wrapping flex with 4px 12px gap
- updated: `21 Aug 26` format, 11px uppercase, letter-spacing 0.06em, #8a8a8a, right aligned
- action: text only, 12px weight 700, letter-spacing 0.06em, right aligned, #8a8a8a, hover #e6e6e6. COPY reads COPIED in #ff5c00 for one second then reverts. OPEN is an anchor. Text actions keep the 44px tap box treatment from replit.md on phones.

Row background is #111 when the row holds the cursor, otherwise transparent. Hover moves the cursor to that row. No transitions anywhere. Click on the row toggles expand (or follows the link for Digest). Click on the action does its action without expanding.

Expanded body: hairline #1f1f1f on top, padding 32px 14px 36px 166px so the reading column starts under the title column. Reading column max-width 72ch, 15px, line-height 1.75, #e6e6e6, overflow-wrap anywhere, rendered with marked under the existing prose rules. Markdown h1 renders 15px weight 700 #e6e6e6; h2 and h3 render 11px weight 500 uppercase letter-spacing 0.14em #8a8a8a. Code blocks: 13px, background #111, border 1px #1f1f1f, padding 12px 14px, horizontal scroll. Inline code: background #1f1f1f, padding 1px 5px. Tables render as preformatted monospace in #8a8a8a. Connect items end with a DOWNLOAD button styled like the row action, labelled `DOWNLOAD 1-API-ACCESS.md`.

Key legend: a single line under the last section, 11px uppercase letter-spacing 0.1em #8a8a8a, items separated by 24px: `j k move`, `enter open`, `c copy`, `/ filter`, `esc clear`. This is the only text on the page that is not content.

### Keyboard

Global, ignored while the filter input has focus (except Esc and Enter, which blur it):
- j or ArrowDown: cursor down one row. k or ArrowUp: cursor up. Clamped to the visible list.
- Enter: toggle expand on the cursor row; on a Digest row, follow the link.
- c: copy the cursor row's body (COPIED feedback as above).
- /: focus the filter. Esc: clear the filter, collapse any open row, blur.

Filtering resets the cursor to the first visible row. Only one row is expanded at a time.

### Responsive

- Below 1000px: hide the tags column; grid becomes `52px 84px minmax(0, 1fr) 84px 64px`.
- Below 760px: hide kind, tags and updated; grid becomes `44px minmax(0, 1fr) auto`; expanded body loses its left padding; status line drops to two columns (clock, filter) and hides the count.
- Base text stays 16px on phones and the input never drops below 16px (iOS zoom rule in replit.md).

## Design rules

- Colours: background #0a0a0a, primary #e6e6e6, secondary #8a8a8a, hairlines #1f1f1f, row cursor fill #111, accent #ff5c00. The accent appears only on the cursor bar, the focused filter underline, focus-visible outlines, and COPIED. Nowhere else.
- Type: JetBrains Mono for everything except the clock, which is the only Gladiator on the page. Gladiator at font-weight normal.
- Flat. No shadows, gradients, cards, icons, images, rounded corners, or motion. Expand and collapse are instant.
- Head: title `Index`, robots noindex kept, favicon unchanged.
- No descriptive or explainer text anywhere on the page. Section labels and the key legend are the only non-content text.

## Do not build

No tabs. No name or wordmark. No footer beyond the key legend. No light mode. No analytics. No new dependencies. Do not touch `/pay`.

## Acceptance checklist

1. All four kinds appear in the fixed order with the refs above, sorted ascending within sections; empty or fully filtered sections vanish, header included.
2. COPY returns the raw markdown body byte exact, frontmatter excluded, from the row and from the `c` key.
3. `/` focuses, Esc clears and collapses, j/k/Enter/c work with the input blurred and do nothing while it has focus.
4. The clock shows Melbourne time, ticks every second, and is the only Gladiator on the page.
5. The accent appears only in the four states listed.
6. At 924px wide, prompt titles occupy the widest column and wrap to at most two lines; at 375px wide, filter, expand, copy and download all work.
7. `/brand`, `/launch` and `/connect` redirect to `/`. Unknown paths still redirect with the one-time notice.
8. Digest rows are real anchors that open the issue URL in the same tab and never expand.
9. No sentence of descriptive copy anywhere on the page.
