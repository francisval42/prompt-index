window.FV_CONTENT = {
  categories: ['Protocols', 'Discovery', 'Generation', 'Repairs', 'Review', 'Builds'],
  titles: { prompts: 'Prompts', brand: 'Brand skill', launch: 'Launch ready', connect: 'Connect' },
  intros: {
    prompts: 'Find one, copy it, leave. Each row opens to the full text; Copy takes the exact file.',
    brand: 'Six steps to a skill file that makes Claude render things the way you would.',
    launch: 'Build rules and a pre-launch audit for apps built with AI tools. Version 1.0, August 2026.',
    connect: 'Check the connector directory first. If it is not there, this pack gets you to a working custom connector.'
  },
  brandSteps: [
    'Open a Cowork chat in Claude.',
    "Give it a brand skill to copy the shape of. The example below works. So does Claude's built-in brand-guidelines skill.",
    "Connect the folder holding your logos, fonts and brand assets. If there isn't one, name your colours and fonts in the chat.",
    'Ask for a skill file for your own brand: colours, type, voice, rules.',
    'It renders a specimen. Correct it until it looks like you.',
    'Save the skill from the file card.'
  ],
  launchSteps: [
    'Copy the build rules into replit.md before the first prompt. Other tools: CLAUDE.md, .cursor/rules, or attach the file at chat start.',
    'Paste the kickoff prompt. The AI confirms the rules, asks the setup questions, builds the scaffold before any feature.',
    'Request features with the feature template. Every feature ends on the definition of done.',
    'Every few features, run a checkpoint sweep: access, duplicates, secrets, schema, queries.',
    'Before launch, run the audit as a second user. Fix every critical.',
    'Rotate every key. Launch.'
  ],
  connectSteps: [
    'List what Claude needs to reach.',
    'Check the connector directory, wire it, stop if covered.',
    'No connector, confirm the service has an API.',
    'Set up API access with 1-API-ACCESS.',
    'Build the server with 2-BUILD-PROMPTS.',
    'Register and test with 3-CONNECT-AND-TEST.'
  ],
  prompts: [
    { id: '001', title: 'Force direct, structured, honest answers for a whole chat', category: 'Protocols', type: 'Protocol', platforms: ['Claude', 'ChatGPT'],
      body: `# Response Protocol

Follow this protocol for the whole conversation unless I explicitly change it.

## HARD CONSTRAINT: NO EM DASHES

Never use an em dash anywhere in your writing. This is absolute. No section, no format, no stylistic situation is an exception, and this constraint outranks every other stylistic consideration in this protocol.

* Also banned when used as a dash: the parenthetical en dash, the double hyphen (--), and a spaced single hyphen splicing two clauses together.
* Ordinary hyphens in compound words (well-known, month-end) are fine.
* Where you would have used a dash, use a comma, a colon, a semicolon, parentheses, or two sentences.

## CORE PRINCIPLE

Your goal is the most accurate, useful and well-reasoned understanding of the subject. Not agreement with me, and not merely answering the literal wording of a badly framed question.

* Never state as fact anything you do not know to be true. Never invent facts, sources, numbers or certainty.
* Do not upgrade an assumption or inference into a fact.
* If you do not know, say so plainly.
* If I push back, do not fold. Restate your reasoning, engage with mine, and change position only if actually persuaded.

## ROUTING

1. **Substantive question**: use the QUESTION FORMAT.
2. **Deliverable request**: use the DELIVERABLE FORMAT.
3. **Trivial lookup**: answer in a sentence or two, no headings.
4. **Follow-up or debate on an active thread**: reply conversationally, no headings.

## QUESTION FORMAT

**DIRECT ANSWER** (always): the answer itself, immediately, with no run-up.

**DETAIL** (usually): only what is needed to understand and trust the answer.

**UNCERTAINTY** (when material): only what survives verification.

**NEXT STEP** (when genuinely useful): the most useful next action. Prefer the useful thing I have not thought to ask.

## STYLE

* Succinct, plain, direct, precise.
* No greetings, no filler, no hedging beyond genuine uncertainty.
* Banned outright: opening with praise of the question or request.` },
    { id: '002', title: 'Break anything into its decisions and interview me through them', category: 'Discovery', type: 'Prompt', platforms: ['Claude', 'ChatGPT', 'Replit Agent'],
      body: `Interview me to define something.

Work out what we're defining from this chat. If it isn't clear, ask, then start.

Break it into the decisions that actually shape it. Tell me how many you count, then ask them one at a time, adapting what you ask to what I've answered. Mark progress on every question, like 3 of 7. If an answer opens a decision you hadn't counted, say so and adjust the count.

Every question is multiple choice. Offer as many options as the decision honestly has, two to five, never padded to a number. Each option is a distinct direction with one line on its vibe and what choosing it implies. Never two shades of the same idea. Close every question with the open option: something else.

Hold your opinion unless one option clearly serves the thing better than the rest. Then name it and give the why in one line.

If I answer skip, make that call yourself, consistent with the direction my answers have set.

Lock my answer in one line, then ask the next question. One question per message.

When the last decision locks, hand over a build-ready brief: every decision stated plainly, the calls you made on my skips marked as yours. Nothing before it, nothing after it, no commentary.

Direct prose. No preamble. No em dashes anywhere, including in the brief.` },
    { id: '003', title: 'Diagnose a broken production app before touching code', category: 'Repairs', type: 'Prompt', platforms: ['Claude', 'Replit Agent'],
      body: `Investigate the current state of this app and produce a status report with a fix plan. Do not change any code, secrets or settings. Diagnosis only.

Take the symptoms from this chat. Verify every claim about the app yourself rather than assuming it.

Report on:

1. App map. Stack, entry points, how the parts are wired, which processes run in production, how it deploys, whether the production deployment is running, crashed or stale, and when it last deployed successfully.

2. Reproduce each symptom. Trigger the failing path and capture it: endpoint, status code, and the server side stack trace from the production deployment logs, not the workspace logs.

3. Auth and integration chain. For every external service the app talks to, document the flow as implemented: credentials, scopes, token storage and refresh, expiry handling. State which links you verified live.

4. Suspects. Rank the likely causes with the evidence for and against each: expired credentials or secrets, state stored somewhere ephemeral, secrets present in the workspace but missing from the deployment, upstream calls failing with errors swallowed into empty results.

5. Environment. List the names of every env var and secret the code reads and whether each is present in production. Never print values, even partially. Flag any read in code but never set.

6. Report. What is definitely broken, what is fine, root causes ranked with evidence, then a step by step fix plan split into changes inside the app and changes I must make elsewhere myself.

Constraints: read only, nothing sent, no secrets printed, no dependency upgrades. Do not mark anything as diagnosed without quoting the production evidence.` }
  ],
  launch: [
    { order: '0', file: '0-START-HERE.md', title: 'The five step process', body: `# Launch Ready

Build rules and a pre-launch audit for apps built with AI tools. Version 1.0, August 2026.

Apps built on Replit, Lovable, Bubble, Base44, or vibe-coded through Cursor and Claude fail in the same eight places: open data access, broken auth edge cases, duplicate workflows, demo-grade database design, queries that die at 500 users, payments that only handle success, silent errors, and exposed keys. None of these show up while you test as yourself with three records. All of them show up when real users arrive.

## The process

**Step 1. Install the rules, before the first prompt.** Get \`1-BUILD-RULES.md\` in front of the AI permanently. Doing this after the app half-exists means retrofitting security.

**Step 2. Kickoff.** Paste the kickoff prompt from \`2-PROMPTS.md\`. The AI confirms the rules, asks the six setup questions, then builds the scaffold first.

**Step 3. Build loop.** Request features with the feature template so every feature ends with a Definition of Done report. Every few features, run one or two checkpoint sweeps.

**Step 4. Pre-launch audit.** Work through \`3-PRE-LAUNCH-AUDIT.md\` with a second test account and Stripe in test mode. Fix every Critical, re-test, rotate all keys, then launch.

**Step 5. After launch.** Re-run the audit after any major feature, any schema change touching user data, or any new integration.` },
    { order: '1', file: '1-BUILD-RULES.md', title: 'Rules the AI must follow', body: `# Build rules\n\nInstalled before the first prompt, present in every session. Access control, secrets, schema, queries, payments, errors. The core file of the pack.` },
    { order: '2', file: '2-PROMPTS.md', title: 'Kickoff, feature template and checkpoint sweeps', body: `# Prompts\n\nCopy-paste prompts used throughout the build: the kickoff, the feature template that ends on a definition of done, and the checkpoint sweeps S1 to S6.` },
    { order: '3', file: '3-PRE-LAUNCH-AUDIT.md', title: 'The self-audit', body: `# Pre-launch audit\n\nTest steps, severity ratings and a report template. Run as a second user before launch and after any major change.` }
  ],
  connect: [
    { order: '0', file: '0-START-HERE.md', title: 'The six step process', body: `0-START-HERE

THE PROCESS

1. List what Claude needs to reach. Email, calendar, files, CRM, phones, whatever the job touches. One line per service.

2. Check the directory. claude.ai settings > Connectors > browse the directory. Claude Code: /mcp. If the service is there, connect it, authorise the account, test with one real task. You are done. Stop.

3. No connector? Confirm the service has an API and your plan includes API access. No API, no build.

4. Set up API access with 1-API-ACCESS. App registration, tenant, redirect URI, scopes, secrets. Complete the checklist before any code exists.

5. Build the server with 2-BUILD-PROMPTS. Every write sits behind confirmed=true.

6. Register and test with 3-CONNECT-AND-TEST. Add the /mcp endpoint as a custom connector, run the smoke tests.

RULES

- Connector before custom. Always check the directory first, it grows every month.
- One server per service, not one per task.
- Writes preview by default. Nothing sends, deletes or books without confirmed=true.
- Secrets live in Replit Secrets, never in code, never in the prompt.
- New scopes invalidate old logins. Build a sign-out button on day one.` },
    { order: '1', file: '1-API-ACCESS.md', title: 'The auth checklist', body: `1-API-ACCESS

THE CHECKLIST

1. Find the developer portal. Microsoft: Azure Portal > App registrations. Google: Cloud Console > Credentials.

2. Register one app per service. Name it after the tool, not the task.

3. Account audience. Decide who can sign in: work accounts only, or work plus personal. Wrong audience fails login with no useful error.

4. Platform type is Web. Not Mobile, not Desktop. Wrong type rejects the redirect silently.

5. Redirect URI. The exact live URL, not localhost. Scheme, host and path must match character for character.

6. Scopes. List every permission the build needs, and always include the refresh token scope: offline_access on Microsoft, access_type=offline on Google.

7. Secrets. Client ID, tenant ID and client secret go into Replit Secrets. Never in code, never in a prompt, never in git.

8. Secret expiry. Client secrets expire. Pick the longest allowed and diarise the renewal.

THE TRAPS

- New scopes kill old logins. Sign out, clear the session, log in fresh.
- Redirect URI mismatch. When login breaks, check this before anything else.
- Admin consent. If login works on a personal account but not the work one, this is it.` },
    { order: '2', file: '2-BUILD-PROMPTS.md', title: 'Build the server', body: `2-BUILD-PROMPTS\n\nPrompt A builds a backend with an MCP server from scratch. Prompt B wraps an existing backend. Either way, every write sits behind confirmed=true.` },
    { order: '3', file: '3-CONNECT-AND-TEST.md', title: 'Register, smoke test, troubleshoot', body: `3-CONNECT-AND-TEST\n\nAdd the /mcp endpoint as a custom connector, run the smoke tests, and keep the troubleshooting card for the day the tools vanish.` }
  ],
  brandExample: `# Francis Valente Brand Styling

## Overview

The personal brand of Francis Valente (francisvalente.com). Near-black surfaces, greyscale type, one vivid orange accent used sparingly. Type does the talking; decoration earns its place or does not appear.

## Colours

- Charcoal background: \`#0a0a0a\`
- Primary text: \`#e6e6e6\`
- Secondary text: \`#8a8a8a\`
- Hairline borders: \`#1f1f1f\`
- Accent orange: \`#ff5c00\`

Orange is scarce. It marks the active, the interactive and the important. Everything else stays greyscale. Flat surfaces only. No gradients, no shadows, no elevated cards, no decorative icons, no stock imagery.

## Typography

- Display and headings: **Gladiator Bold**. Page titles, section headings, one-line statements. Never body text.
- Everything else: **JetBrains Mono** (400, 500, 700). Body, UI, labels, captions, code.

## Voice

- No em dashes, anywhere, ever.
- No explainer text. If a heading needs a subtitle to be understood, fix the heading.
- Direct prose, Australian English, no buzzwords, no preamble, no marketing cadence.`
};
